function mergeSort(left_part, right_part) {
    var i = 0;
    var j = 0;
    var results = [];

    while(i < left_part.length || j < right_part.length) {
        if(i === left_part.length){
            results.push(right_part[j]);
            j++;
        } else if(j === right_part.length || left_part[i] <= right_part[j]){
            results.push(left_part[i]);
            i++;
        } else {
            results.push(right_part[j]);
            j++;
        }
    }
    return results;
}

console.log(mergeSort([1,3,4], [3,7,9]));
